#include "wifi_controller.h"
#include <stdio.h>
#include <string.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "nvs_flash.h"

static const char* TAG = "wifi_controller";
static bool wifi_inited = false;
static uint8_t original_mac_ap[6];

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data){}

static void wifi_init_apsta(){
    esp_netif_create_default_wifi_ap();
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t c = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&c));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_wifi_get_mac(WIFI_IF_AP, original_mac_ap));
    ESP_ERROR_CHECK(esp_wifi_start());
    wifi_inited = true;
}

// Публичная init - вызывается из main один раз
void wifictl_init(void){
    esp_err_t r = nvs_flash_init();
    if(r == ESP_ERR_NVS_NO_FREE_PAGES || r == ESP_ERR_NVS_NEW_VERSION_FOUND){
        ESP_ERROR_CHECK(nvs_flash_erase());
        r = nvs_flash_init();
    }
    ESP_ERROR_CHECK(r);
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    wifi_init_apsta();
}

void wifictl_ap_start(wifi_config_t *wifi_config){
    if(!wifi_inited) wifi_init_apsta();
    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, wifi_config));
}

void wifictl_ap_stop(){
    wifi_config_t c = { .ap = { .max_connection = 0 } };
    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &c));
}

void wifictl_mgmt_ap_start(){
    wifi_config_t c = {
        .ap = {
            .ssid = CONFIG_MGMT_AP_SSID,
            .ssid_len = strlen(CONFIG_MGMT_AP_SSID),
            .password = CONFIG_MGMT_AP_PASSWORD,
            .max_connection = CONFIG_MGMT_AP_MAX_CONNECTIONS,
            .authmode = WIFI_AUTH_WPA2_PSK
        },
    };
    wifictl_ap_start(&c);
}

void wifictl_sta_connect_to_ap(const wifi_ap_record_t *ap_record, const char password[]){
    if(!wifi_inited) wifi_init_apsta();
    wifi_config_t c = {
        .sta = { .channel=ap_record->primary, .scan_method=WIFI_FAST_SCAN,
                 .pmf_cfg.capable=false, .pmf_cfg.required=false }
    };
    memcpy(c.sta.ssid, ap_record->ssid, 32);
    if(password && strlen(password) < 64)
        memcpy(c.sta.password, password, strlen(password)+1);
    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_STA, &c));
    ESP_ERROR_CHECK(esp_wifi_connect());
}

void wifictl_sta_disconnect(){ ESP_ERROR_CHECK(esp_wifi_disconnect()); }
void wifictl_set_ap_mac(const uint8_t *m){ ESP_ERROR_CHECK(esp_wifi_set_mac(WIFI_IF_AP, m)); }
void wifictl_get_ap_mac(uint8_t *m){ esp_wifi_get_mac(WIFI_IF_AP, m); }
void wifictl_restore_ap_mac(){ ESP_ERROR_CHECK(esp_wifi_set_mac(WIFI_IF_AP, original_mac_ap)); }
void wifictl_get_sta_mac(uint8_t *m){ esp_wifi_get_mac(WIFI_IF_STA, m); }
void wifictl_set_channel(uint8_t ch){
    if(ch==0||ch>13) return;
    esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
}
