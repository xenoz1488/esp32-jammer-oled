#include "attack.h"
#include <stdlib.h>
#include <string.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_err.h"
#include "esp_timer.h"
#include "attack_dos.h"

static const char *TAG = "attack";
static attack_status_t status = { .state=READY, .type=-1, .content_size=0, .content=NULL };
static esp_timer_handle_t timeout_handle;

const attack_status_t *attack_get_status(){ return &status; }

void attack_update_status(attack_state_t state){
    status.state = state;
    if(state == FINISHED || state == TIMEOUT)
        esp_timer_stop(timeout_handle); // игнорируем ошибку если таймер не запущен
}

void attack_append_status_content(uint8_t *buf, unsigned size){
    if(!size) return;
    char *p = realloc(status.content, status.content_size + size);
    if(!p) return;
    memcpy(&p[status.content_size], buf, size);
    status.content = p;
    status.content_size += size;
}

char *attack_alloc_result_content(unsigned size){
    status.content_size = size;
    status.content = malloc(size);
    return status.content;
}

static void on_timeout(void *arg){
    ESP_LOGI(TAG, "Attack timeout");
    status.state = TIMEOUT;
    if(status.type == ATTACK_TYPE_DOS) attack_dos_stop();
}

void attack_init(){
    const esp_timer_create_args_t args = { .callback=&on_timeout, .name="atk_timeout" };
    ESP_ERROR_CHECK(esp_timer_create(&args, &timeout_handle));
}

void attack_start(attack_config_t *cfg){
    if(!cfg) return;
    // Освободить старый контент
    free(status.content);
    status.content = NULL;
    status.content_size = 0;
    status.state = RUNNING;
    status.type  = cfg->type;

    // Запустить таймер только если timeout > 0
    if(cfg->timeout > 0){
        esp_timer_start_once(timeout_handle, (uint64_t)cfg->timeout * 1000000ULL);
        ESP_LOGI(TAG, "Timeout set: %lu s", (unsigned long)cfg->timeout);
    } else {
        ESP_LOGI(TAG, "Timeout: infinite");
    }

    if(cfg->type == ATTACK_TYPE_DOS)
        attack_dos_start(cfg);
    else
        ESP_LOGE(TAG, "Unknown attack type %d", cfg->type);
}

void attack_stop(){
    esp_timer_stop(timeout_handle);
    if(status.type == ATTACK_TYPE_DOS) attack_dos_stop();
    status.state = FINISHED;
    status.type  = -1;
    ESP_LOGI(TAG, "Attack stopped");
}
